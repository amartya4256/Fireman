from flask import Flask, request, redirect, url_for, jsonify
from flask_api import status
import sqlite3
from flask_login import LoginManager,UserMixin,current_user,login_user,login_required, logout_user
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import json


global database


database = "UserServer/TestDb.db"


app = Flask(__name__)
cors = CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user_database.db'
app.config['SECRET_KEY'] = "LOL YOU CAN NEVER GUESS IT"
dbs = SQLAlchemy(app)
login=LoginManager(app)
login.login_view='/'

class user_database(UserMixin,dbs.Model):
    id = dbs.Column(dbs.Integer, primary_key = True)
    password = dbs.Column(dbs.String(100))

def report_counter(row_data):
    return row_data['Count']

@login.user_loader
def load_user(user_id):
    return user_database.query.get(int(user_id))

@app.route("/", methods = ['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        print("Goyo")
        return "yes"
    elif request.method == "POST":
        data = request.data
        data = json.loads(data.decode("utf-8").replace("'", '"'))
        user_id = data['id']
        user_pass = data['password']

        try:
            connection_user = sqlite3.connect("user_database.db")
            c_user = connection_user.cursor()
            query = "select password from user_database where id = {}".format(user_id)
            c_user.execute(query)
            actual_pass = c_user.fetchone()
            if (actual_pass[0] == user_pass):
                user_login = user_database.query.filter_by(id=user_id).first()
                login_user(user_login)
                print("yo")
                return "yes"
            else:
                print("naah")
                return "no"
        except:
            return "no"
    else:
        return "login here"

@app.route('/dashboard', defaults={'value': None})
@app.route('/dashboard/<value>')
#login_required
def dbupdater(value):
    print("Hi")
    connection = sqlite3.connect("{}".format(database))
    c = connection.cursor()
    if value:
        try:
            query = ["DELETE FROM UserReports WHERE LocationId = {}".format(value), "DELETE FROM Locations WHERE Id = {}".format(value)]
            print(query)
            for queries in query:
                c.execute(queries)
            connection.commit()
            return "", status.HTTP_200_OK
        except:
            return "", status.HTTP_404_NOT_FOUND
    else:
        query = "SELECT * FROM Locations"
        print(query)
        c.execute(query)
        data = c.fetchall()
        send_data = list()
        for rows in data:
            try:
                c.execute("SELECT count(LocationId) from UserReports where LocationId = {}".format(rows[0]))
                count = c.fetchone()
            except:
                count = None
            send_data.append({'Id':rows[0], 'Latitude':rows[1], 'Longitude':rows[2], 'Timestamp' : rows[3], 'Address' : rows[4], 'Description' : rows[5], 'Count' : count[0]})
        send_data.sort(key = report_counter, reverse=True)
        return jsonify(send_data)

@app.route("/dashboard/update/<value>", methods = ['POST'])
#login_required
def desc_updater(value):
    connection = sqlite3.connect("{}".format(database))
    c = connection.cursor()
    updated_desc = request.data
    updated_desc = json.loads(updated_desc.decode("utf-8").replace("'", '"'))['Description']
    print(updated_desc)
    query = "UPDATE Locations SET Description = '{}' where Id = {}".format(updated_desc, value)
    print(query)
    c.execute(query)
    connection.commit()
    return "", status.HTTP_200_OK

@app.route("/dashboard/view/<value>")
def img_viewer(value):
    conn = sqlite3.connect(database)
    c = conn.cursor()
    query = "SELECT ImageAsBase64, Description from UserReports where LocationID = {}".format(value)
    c.execute(query)
    data = c.fetchall()
    img_list = list()
    for rows in data:
        img_list.append({'Image':rows[0], 'Description':rows[1]})
    return jsonify(img_list)

if __name__ == '__main__':
    app.run()