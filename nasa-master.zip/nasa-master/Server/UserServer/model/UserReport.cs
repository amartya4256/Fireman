using System;

namespace NasaServer.Model
{
    public class UserReport
    {
        public int Id { get; set; }
        public virtual Location Location { get; set; }
        public string ImageAsBase64 { get; set; }
        public DateTime Timestamp { get; set; }

        public string Description { get; set; }
    }
}