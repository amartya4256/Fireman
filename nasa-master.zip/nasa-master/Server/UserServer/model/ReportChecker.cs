using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace NasaServer.Model
{
    static class ReportChecker
    {
        // Add your Computer Vision subscription key and endpoint to your environment variables.
        const string subscriptionKey = "cfd72755133c497e8d798e58c9234fae";

        const string endpoint = "https://firedetector.cognitiveservices.azure.com/";

        // the Analyze method endpoint
        const string uriBase = endpoint + "vision/v2.0/analyze";

        internal static async Task<bool> CheckReportAsync(UserReport value)
        {
            bool isValidReport = await CheckImageAsync(value.ImageAsBase64);
            return isValidReport;
        }

        private static async Task<bool> CheckImageAsync(string base64Img)
        {
            string[] inclusionList = new string[]{"fire","flame","smoke"};
            double minThreshold = 0.5;
            
            var allTags = await MakeAnalysisRequest(base64Img);
            try
            {
                var y = allTags.Where(x=>inclusionList.Contains(x.Name)).FirstOrDefault(x=>x.Confidence>minThreshold);
                return y!=null;
            }
            catch (System.Exception e)
            {
                return false;
            }
            
        }

        /// <summary>
        /// Gets the analysis of the specified image file by using
        /// the Computer Vision REST API.
        /// </summary>
        /// <param name="base64Image">The image file as base64.</param>
        static async Task<IList<Tag>> MakeAnalysisRequest(string base64Image)
        {
            try
            {
                HttpClient client = new HttpClient();

                // Request headers.
                client.DefaultRequestHeaders.Add(
                    "Ocp-Apim-Subscription-Key", subscriptionKey);

                // Request parameters. A third optional parameter is "details".
                // The Analyze Image method returns information about the following
                // visual features:
                // Categories:  categorizes image content according to a
                //              taxonomy defined in documentation.
                // Description: describes the image content with a complete
                //              sentence in supported languages.
                // Color:       determines the accent color, dominant color, 
                //              and whether an image is black & white.
                string requestParameters =
                    "visualFeatures=Tags";

                // Assemble the URI for the REST API method.
                string uri = uriBase + "?" + requestParameters;

                HttpResponseMessage response;

                // Convert base64 image into byte array
                byte[] byteData = Convert.FromBase64String(base64Image);

                // Add the byte array as an octet stream to the request body.
                using (ByteArrayContent content = new ByteArrayContent(byteData))
                {
                    // This example uses the "application/octet-stream" content type.
                    // The other content types you can use are "application/json"
                    // and "multipart/form-data".
                    content.Headers.ContentType =
                        new MediaTypeHeaderValue("application/octet-stream");

                    // Asynchronously call the REST API method.
                    response = await client.PostAsync(uri, content);
                }

                // Asynchronously get the JSON response.
                string contentString = await response.Content.ReadAsStringAsync();

                // Display the JSON response.
                // var x = JsonConvert.DeserializeObject<Dictionary<string,List<Tag>>>(contentString);
                // return JToken.Parse(contentString);
                
                dynamic res = JObject.Parse(contentString);
                JArray tags = res["tags"];

                JArray array = tags;
                IList<Tag> objList = new List<Tag>();
                foreach (var item in array)
                {
                    objList.Add(item.ToObject<Tag>());
                }

                return objList;
            }
            catch (Exception e)
            {
                Console.WriteLine("\n" + e.Message);
                return null;
            }
        }

        private class Tag
        {
            public string Name { get; set; }
            public double Confidence { get; set; }
        }
    }
}