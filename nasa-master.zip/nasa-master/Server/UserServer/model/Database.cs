using Microsoft.EntityFrameworkCore;

namespace NasaServer.Model
{
    public class Database : DbContext
    {
        public Database(DbContextOptions<Database> options) : base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    => optionsBuilder
        .UseLazyLoadingProxies();
        // .UseSqlServer(myConnectionString);

        public DbSet<Location> Locations { get; set; }
        public DbSet<UserReport> UserReports { get; set; }
    }
}