using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NasaServer.Model;

namespace NasaServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : Controller
    {
        private readonly Database _context;

        public LocationController(Database context)
        {
            _context = context;
        }

        [HttpGet]
        // GET: Location
        public async Task<IActionResult> Index()
        {
            var origList = await _context.Locations.ToListAsync();

            var locations = new List<LocationVM>();
            foreach (var location in origList)
            {

                location.Reports = null;

                locations.Add(new LocationVM(location));
            }
            return Ok(locations);
        }

        class LocationVM
        {
            public double Latitude { get; set; }
            public double Longitude { get; set; }
            public string Description { get; set; }
            public int Count { get; set; }

            public LocationVM(Location location)
            {
                this.Latitude = location.Latitude;
                this.Longitude = location.Longitude;
                this.Count = location.Reports.Count;
                this.Description = location.Description;
            }
        }
    }
}
