using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NasaServer.Model;
using OpenCage.Geocode;

namespace NasaServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : Controller
    {
        private readonly Database _context;

        public ReportController(Database context)
        {
            _context = context;
        }

        // GET: Report
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            return Ok(await _context.UserReports.ToListAsync());
        }

        // // GET: Report/Details/5
        // [Route("/Details/{id}")]
        // public async Task<IActionResult> Details(int? id)
        // {
        //     if (id == null)
        //     {
        //         return NotFound();
        //     }

        //     var userReport = await _context.UserReports
        //         .FirstOrDefaultAsync(m => m.Id == id);
        //     if (userReport == null)
        //     {
        //         return NotFound();
        //     }

        //     return Ok(userReport);
        // }

        // POST: Report/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<IActionResult> Create(UserReport userReport)
        {
            System.Console.WriteLine("Given description: " + userReport.Description);
            if (await ReportChecker.CheckReportAsync(userReport))
            {
                userReport.Timestamp = DateTime.Now;
                userReport.Location = await getLocationAsync(userReport.Location);
                // https://api.opencagedata.com/geocode/v1/json?key=fbda28c3debc45068085c30234b52ac5&pretty=1&q=28.4592%2C+77.5272
                _context.Add(userReport);
                await _context.SaveChangesAsync();
                // return RedirectToAction(nameof(Index));
                return Ok("yes");
            }
            else
            {
                Console.WriteLine("Image is not of fire");
                return Ok("no");
            }
        }

        private async Task<Model.Location> getLocationAsync(Model.Location location)
        {
            double threshold = 0.003;
            var res = _context.Locations.FirstOrDefault(x => Math.Sqrt(Math.Pow((x.Latitude - location.Latitude), 2) + Math.Pow((x.Longitude - location.Longitude), 2)) <= threshold);
            if (res == null)
            {
                location.Description = "Waiting for confirmation";
                location.Address = await getAddressAsync(location);
                return location;
            }
            return res;

            async Task<string> getAddressAsync(Model.Location location1)
            {
                var gc = new Geocoder("fbda28c3debc45068085c30234b52ac5");
                var result = await gc.ReverseGeocodeAsync(location1.Latitude,location1.Longitude);
                return result.Results[0].Formatted;                
            }
        }

        private bool UserReportExists(int id)
        {
            return _context.UserReports.Any(e => e.Id == id);
        }
    }
}
