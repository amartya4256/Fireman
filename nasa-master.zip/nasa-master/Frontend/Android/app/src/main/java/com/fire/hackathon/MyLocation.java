package com.fire.hackathon;

public class MyLocation {
    public String Latitude;
    public String Longitude;

    public  MyLocation(String lat, String lon){
        Latitude = lat;
        Longitude = lon;
    }
}
